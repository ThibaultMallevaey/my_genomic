import sys
import genomic.genomic 
import argparse
import genomic.tools


def main():
    parser = argparse.ArgumentParser(
        prog="parse",
        usage="parse filename",
        description="genomic.genomic.parse()",
    )
    parser.add_argument(
          "filename",
          type=str,
          help="Path to your file",
    )
    args = parser.parse_args()
    filename = args.filename
    return genomic.genomic.parse(filename)

if __name__ == "__main__":
        main()
        
