import setuptools
setuptools.setup(
    name = "my-genomic",
    description="un module pour lire les fichiers fasta",
    packages=setuptools.find_packages(),
    entry_points={"console_scripts": ["my-module = my_module.genomic.__main__:main"]},
)


